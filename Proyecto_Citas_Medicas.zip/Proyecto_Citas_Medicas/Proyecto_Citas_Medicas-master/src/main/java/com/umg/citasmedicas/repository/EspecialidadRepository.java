package com.umg.citasmedicas.repository;

import com.umg.citasmedicas.entity.Especialidad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EspecialidadRepository
        extends JpaRepository<Especialidad, Long> {
}