package com.umg.citasmedicas.service;

import com.umg.citasmedicas.entity.Cita;
import com.umg.citasmedicas.entity.HorarioDisponible;
import com.umg.citasmedicas.enums.EstadoCita;
import com.umg.citasmedicas.repository.CitaRepository;
import com.umg.citasmedicas.repository.HorarioDisponibleRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CitaService {

    private final CitaRepository citaRepository;
    private final HorarioDisponibleRepository horarioRepository;

    public CitaService(
            CitaRepository citaRepository,
            HorarioDisponibleRepository horarioRepository) {

        this.citaRepository = citaRepository;
        this.horarioRepository = horarioRepository;
    }

    public List<Cita> listarTodas() {
        return citaRepository.findAll();
    }

    public Optional<Cita> buscarPorId(Long id) {
        return citaRepository.findById(id);
    }

    public List<Cita> listarPorPaciente(Long pacienteId) {
        return citaRepository.findByPacienteId(pacienteId);
    }

    public List<Cita> listarPorMedico(Long medicoId) {
        return citaRepository.findByMedicoId(medicoId);
    }

    @Transactional
    public Cita crearCita(Cita cita) {

        if (cita.getHorario() == null || cita.getHorario().getId() == null) {
            throw new RuntimeException("Debe seleccionar un horario.");
        }

        Long horarioId = cita.getHorario().getId();

        HorarioDisponible horario = horarioRepository
                .findById(horarioId)
                .orElseThrow(() ->
                        new RuntimeException("Horario no encontrado."));

        if (!horario.isDisponible()) {
            throw new RuntimeException("El horario no está disponible.");
        }

        if (citaRepository.existsByHorarioId(horarioId)) {
            throw new RuntimeException("El horario ya fue reservado.");
        }

        cita.setHorario(horario);
        cita.setMedico(horario.getMedico());
        cita.setEstado(EstadoCita.PENDIENTE);

        horario.setDisponible(false);
        horarioRepository.save(horario);

        return citaRepository.save(cita);
    }

    public Cita guardar(Cita cita) {
        return citaRepository.save(cita);
    }
}