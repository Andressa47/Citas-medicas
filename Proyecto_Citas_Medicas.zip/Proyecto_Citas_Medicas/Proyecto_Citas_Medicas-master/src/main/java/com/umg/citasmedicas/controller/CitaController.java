package com.umg.citasmedicas.controller;

import com.umg.citasmedicas.entity.Cita;
import com.umg.citasmedicas.entity.Usuario;
import com.umg.citasmedicas.enums.EstadoCita;
import com.umg.citasmedicas.repository.UsuarioRepository;
import com.umg.citasmedicas.service.CitaService;

import java.security.Principal;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/appointments")
public class CitaController {

    private final CitaService citaService;
    private final UsuarioRepository usuarioRepository;

    public CitaController(
            CitaService citaService,
            UsuarioRepository usuarioRepository) {

        this.citaService = citaService;
        this.usuarioRepository = usuarioRepository;
    }

    // ==========================================
    // CREAR CITA
    // ==========================================
    @PostMapping
    public ResponseEntity<Cita> crear(
            @RequestBody Cita cita) {

        return ResponseEntity.ok(
                citaService.crearCita(cita)
        );
    }

    // ==========================================
    // LISTAR TODAS LAS CITAS
    // ==========================================
    @GetMapping
    public List<Cita> listarTodas() {
        return citaService.listarTodas();
    }

    // ==========================================
    // MI HISTORIAL
    // Usuario autenticado mediante JWT
    // ==========================================
    @GetMapping("/my-history")
    public ResponseEntity<List<Cita>> miHistorial(
            Principal principal) {

        String email = principal.getName();

        Usuario usuario = usuarioRepository
                .findByEmail(email)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Usuario autenticado no encontrado."
                        )
                );

        return ResponseEntity.ok(
                citaService.listarPorPaciente(
                        usuario.getId()
                )
        );
    }

    // ==========================================
    // HISTORIAL POR ID DE PACIENTE
    // Endpoint auxiliar
    // ==========================================
    @GetMapping("/patient/{pacienteId}")
    public List<Cita> historialPaciente(
            @PathVariable Long pacienteId) {

        return citaService.listarPorPaciente(
                pacienteId
        );
    }

    // ==========================================
    // LISTAR CITAS DE UN MÉDICO
    // ==========================================
    @GetMapping("/doctor/{medicoId}")
    public List<Cita> citasMedico(
            @PathVariable Long medicoId) {

        return citaService.listarPorMedico(
                medicoId
        );
    }

    // ==========================================
    // REGISTRAR DIAGNÓSTICO Y RECETA
    // ==========================================
    @PutMapping("/{id}/diagnosis")
    public ResponseEntity<Cita> registrarDiagnostico(
            @PathVariable Long id,
            @RequestBody Cita datos) {

        return citaService.buscarPorId(id)
                .map(cita -> {

                    cita.setDiagnostico(
                            datos.getDiagnostico()
                    );

                    cita.setReceta(
                            datos.getReceta()
                    );

                    cita.setEstado(
                            EstadoCita.COMPLETADA
                    );

                    return ResponseEntity.ok(
                            citaService.guardar(cita)
                    );
                })
                .orElse(
                        ResponseEntity.notFound().build()
                );
    }

    // ==========================================
    // BUSCAR CITA POR ID
    // ==========================================
    @GetMapping("/{id}")
    public ResponseEntity<Cita> buscarPorId(
            @PathVariable Long id) {

        return citaService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(
                        ResponseEntity.notFound().build()
                );
    }
}