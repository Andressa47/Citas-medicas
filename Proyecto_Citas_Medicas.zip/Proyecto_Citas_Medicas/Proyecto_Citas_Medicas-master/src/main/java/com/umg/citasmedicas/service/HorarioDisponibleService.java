package com.umg.citasmedicas.service;

import com.umg.citasmedicas.entity.HorarioDisponible;
import com.umg.citasmedicas.repository.HorarioDisponibleRepository;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class HorarioDisponibleService {

    private final HorarioDisponibleRepository horarioRepository;

    public HorarioDisponibleService(HorarioDisponibleRepository horarioRepository) {
        this.horarioRepository = horarioRepository;
    }

    public List<HorarioDisponible> listarTodos() {
        return horarioRepository.findAll();
    }

    public Optional<HorarioDisponible> buscarPorId(Long id) {
        return horarioRepository.findById(id);
    }

    public List<HorarioDisponible> listarDisponiblesPorMedico(Long medicoId) {
        return horarioRepository.findByMedicoIdAndDisponibleTrue(medicoId);
    }

    public List<HorarioDisponible> listarDisponiblesPorMedicoYFecha(
            Long medicoId,
            LocalDate fecha) {

        LocalDateTime inicio = fecha.atStartOfDay();
        LocalDateTime fin = fecha.atTime(LocalTime.MAX);

        return horarioRepository
                .findByMedicoIdAndFechaHoraInicioBetweenAndDisponibleTrue(
                        medicoId,
                        inicio,
                        fin
                );
    }

    public HorarioDisponible guardar(HorarioDisponible horario) {
        return horarioRepository.save(horario);
    }

    public void eliminar(Long id) {
        horarioRepository.deleteById(id);
    }
}