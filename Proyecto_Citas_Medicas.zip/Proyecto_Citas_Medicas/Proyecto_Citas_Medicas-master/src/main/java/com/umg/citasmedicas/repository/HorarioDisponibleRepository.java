package com.umg.citasmedicas.repository;

import com.umg.citasmedicas.entity.HorarioDisponible;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HorarioDisponibleRepository
        extends JpaRepository<HorarioDisponible, Long> {

    List<HorarioDisponible> findByMedicoIdAndDisponibleTrue(Long medicoId);

    List<HorarioDisponible>
        findByMedicoIdAndFechaHoraInicioBetweenAndDisponibleTrue(
            Long medicoId,
            LocalDateTime inicio,
            LocalDateTime fin
        );
}